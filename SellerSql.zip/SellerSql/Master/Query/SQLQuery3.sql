﻿SELECT Price.MainPrice FROM Price JOIN Product ON Price.ProductId=Product.Id and Product.ProductName Like N'%سامسونگ%'

select * from Order_
select * From OrderLine join Order_ on OrderLine.OrderId=Order_.Id
