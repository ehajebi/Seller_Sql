﻿Create Procedure Sp_Orders_Customer
As
Begin 
select * from Orders_Customer
End;

Exec Sp_Orders_Customer;
Go
create Procedure Sp_InsertState
As
Begin
INSERT INTO State(Id,Name) VALUES (NEWID(), N'مشهد')
End
Exec Sp_InsertState;
Go

Create Procedure Sp_State
As
Begin 
select * from State
End;
Exec Sp_State;
Go


