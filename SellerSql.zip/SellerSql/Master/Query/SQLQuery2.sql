﻿--select * from store

--select * from category

--select  Category.CategoryName
--from Category
--where Category.ParentId Is Null

select  Category.CategoryName
from Category
where Category.ParentId Is not Null and Category.CategoryName like N'%موبایل%'

select *from Product

SELECT * 
from Product 
where Product.CategoryId in(select Category.Id from Category where CategoryName like N'%موبایل%')



