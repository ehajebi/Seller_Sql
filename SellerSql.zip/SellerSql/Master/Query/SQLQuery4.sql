
select Customer.CustomerName from Customer_Address join Customer on Customer_Address.CustomerId = Customer.Id join Address on 