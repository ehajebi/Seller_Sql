﻿Drop DATABASE IF EXISTS Sellertest;
Go

CREATE DATABASE Sellertest;
Go

USE  Sellertest;
GO
------------CREATE TABLE *Store*---------------------

Drop TABLE IF EXISTS Store;
Go
CREATE TABLE Store
(	
	Id uniqueidentifier NOT NULL,
	StoreName nvarchar(150),
	Primary Key(Id)
);
GO
INSERT INTO Store (Id,StoreName)
VALUES (NEWID(),N'مرکزی');

----------------Create Table *Category*---------------



Drop TABLE IF EXISTS Category;
Go
CREATE TABLE Category 
(	
	Id uniqueidentifier NOT NULL,
	ParentId uniqueidentifier,
	CategoryName NVARCHAR(20)NOT NULL,
	Primary Key(Id),
	Foreign key(ParentId) references Category
		ON DELETE No Action
		on update No Action

);
GO
INSERT INTO Category (Id,ParentId,CategoryName)
VALUES (NEWID(),null,N'دیجیتال')

INSERT INTO Category (Id,ParentId,CategoryName)
VALUES (NEWID(),(select Id from Category c where c.CategoryName like N'%دیجیتال%'),N'موبایل')

INSERT INTO Category (Id,ParentId,CategoryName)
VALUES (NEWID(),(select Id from Category c where c.CategoryName like N'%دیجیتال%'),N'لپ تاپ')

INSERT INTO Category (Id,ParentId,CategoryName)
VALUES (NEWID(),(select Id from Category c where c.CategoryName like N'%دیجیتال%'),N'تبلت')

INSERT INTO Category (Id,ParentId,CategoryName)
VALUES (NEWID(),null,N'لوازم تحریر')

INSERT INTO Category (Id,ParentId,CategoryName)
VALUES (NEWID(),(select Id from Category c where c.CategoryName like N'%لوازم تحریر%'),N'کیف')

INSERT INTO Category (Id,ParentId,CategoryName)
VALUES (NEWID(),(select Id from Category c where c.CategoryName like N'%لوازم تحریر%'),N'خودکار و روان نویس')

INSERT INTO Category (Id,ParentId,CategoryName)
VALUES (NEWID(),(select Id from Category c where c.CategoryName like N'%لوازم تحریر%'),N'دفتر و کاغذ');


Drop TABLE IF EXISTS Product;
Go
CREATE TABLE Product 
(	
	Id uniqueidentifier NOT NULL,
	StoreId uniqueidentifier,
	CategoryId uniqueidentifier,
	ProductName NVARCHAR(20) NOT NULL,
	--Price decimal(18,4),
	--DiscoutId uniqueidentifier,
	Primary Key(Id),
	Foreign key(StoreId) references Store
		ON DELETE SET NULL
		on update cascade,
	Foreign key(CategoryId) references Category
		ON DELETE SET NULL
		on update NO Action
);
GO

INSERT INTO Product(Id ,StoreId, CategoryId,ProductName)
VALUES (NEWID(),(select Store.Id from store where Store.StoreName like N'%مرکزی%'),(select Category.Id from Category where Category.ParentId Is not Null and Category.CategoryName like N'%موبایل%'),N'سامسونگ')

INSERT INTO Product(Id ,StoreId, CategoryId,ProductName)
VALUES (NEWID(),(select Store.Id from store where Store.StoreName like N'%مرکزی%'),(select Category.Id from Category where Category.ParentId Is not Null and Category.CategoryName like N'%موبایل%'),N'شیائومی')

INSERT INTO Product(Id ,StoreId, CategoryId,ProductName)
VALUES (NEWID(),(select Store.Id from store where Store.StoreName like N'%مرکزی%'),(select Category.Id from Category where Category.ParentId Is not Null and Category.CategoryName like N'%موبایل%'),N'آنر')

INSERT INTO Product(Id ,StoreId, CategoryId,ProductName)
VALUES (NEWID(),(select Store.Id from store where Store.StoreName like N'%مرکزی%'),(select Category.Id from Category where Category.ParentId Is not Null and Category.CategoryName like N'%کیف%'),N'کوله پشتی')

INSERT INTO Product(Id ,StoreId, CategoryId,ProductName)
VALUES (NEWID(),(select Store.Id from store where Store.StoreName like N'%مرکزی%'),(select Category.Id from Category where Category.ParentId Is not Null and Category.CategoryName like N'%کیف%'),N'کیف دستی')

INSERT INTO Product(Id ,StoreId, CategoryId,ProductName)
VALUES (NEWID(),(select Store.Id from store where Store.StoreName like N'%مرکزی%'),(select Category.Id from Category where Category.ParentId Is not Null and Category.CategoryName like N'%لپ تاپ%'),N'ایسوس')

INSERT INTO Product(Id ,StoreId, CategoryId,ProductName)
VALUES (NEWID(),(select Store.Id from store where Store.StoreName like N'%مرکزی%'),(select Category.Id from Category where Category.ParentId Is not Null and Category.CategoryName like N'%لپ تاپ%'),N'اچ پی')

INSERT INTO Product(Id ,StoreId, CategoryId,ProductName)
VALUES (NEWID(),(select Store.Id from store where Store.StoreName like N'%مرکزی%'),(select Category.Id from Category where Category.ParentId Is not Null and Category.CategoryName like N'%لپ تاپ%'),N'سونی');


Drop TABLE IF EXISTS Price;
Go
CREATE TABLE Price
(
	Id uniqueidentifier NOT NULL,
	ProductId uniqueidentifier NOT NULL,
	MainPrice Decimal(18,6),
	ColleaguePrice Decimal(18,6),
	MajorPrice Decimal(18,6),
	Primary Key(Id),
	FOREIGN KEY (ProductId) REFERENCES Product
		on delete no action
		on update no action
);
GO

INSERT INTO Price(Id ,ProductId, MainPrice,ColleaguePrice,MajorPrice)
VALUES (NEWID(),(select Id from Product where Product.ProductName like N'%سامسونگ%'),10000000,8000000,7000000)

INSERT INTO Price(Id ,ProductId, MainPrice,ColleaguePrice,MajorPrice)
VALUES (NEWID(),(select Id from Product where Product.ProductName like N'%آنر%'),7000000,6000000,5000000)

INSERT INTO Price(Id ,ProductId, MainPrice,ColleaguePrice,MajorPrice)
VALUES (NEWID(),(select Id from Product where Product.ProductName like N'%شیائومی%'),90000000,7000000,6000000)

INSERT INTO Price(Id ,ProductId, MainPrice,ColleaguePrice,MajorPrice)
VALUES (NEWID(),(select Id from Product where Product.ProductName like N'%سونی%'),900000000,70000000,60000000)

INSERT INTO Price(Id ,ProductId, MainPrice,ColleaguePrice,MajorPrice)
VALUES (NEWID(),(select Id from Product where Product.ProductName like N'%اچ پی%'),40000000,35000000,30000000)

INSERT INTO Price(Id ,ProductId, MainPrice,ColleaguePrice,MajorPrice)
VALUES (NEWID(),(select Id from Product where Product.ProductName like N'%ایسوس%'),600000000,55000000,50000000)

INSERT INTO Price(Id ,ProductId, MainPrice,ColleaguePrice,MajorPrice)
VALUES (NEWID(),(select Id from Product where Product.ProductName like N'%کوله پشتی%'),600000,500000,450000)

INSERT INTO Price(Id ,ProductId, MainPrice,ColleaguePrice,MajorPrice)
VALUES (NEWID(),(select Id from Product where Product.ProductName like N'%کیف دستی%'),450000,300000,350000);


--موجودی
---در صورتی که چند انبار داشته باشیم
Drop TABLE IF EXISTS Inventory;
Go
CREATE TABLE Inventory
(
	--Id uniqueidentifier NOT NULL,
	ProductId uniqueidentifier NOT NULL,
	StoreId uniqueidentifier NOT NULL,
	Quantity decimal(12,4),
	Primary Key(ProductId,StoreId),
	foreign key(ProductId) references Product---------------------
		on delete no action
		on update no action,                     
	foreign key(StoreId) references Store---------------------
		on delete no action
		on update no action

);
GO

INSERT INTO Inventory(ProductId, StoreId,Quantity)
VALUES ((select Id from Product where Product.ProductName like N'%کیف دستی%'),(select Id from Store where StoreName like N'%مرکزی%'),500)

INSERT INTO Inventory(ProductId, StoreId,Quantity)
VALUES ((select Id from Product where Product.ProductName like N'%سامسونگ%'),(select Id from Store where StoreName like N'%مرکزی%'),200)

INSERT INTO Inventory(ProductId, StoreId,Quantity)
VALUES ((select Id from Product where Product.ProductName like N'%شیائومی%'),(select Id from Store where StoreName like N'%مرکزی%'),150)

INSERT INTO Inventory(ProductId, StoreId,Quantity)
VALUES ((select Id from Product where Product.ProductName like N'%اچ پی%'),(select Id from Store where StoreName like N'%مرکزی%'),50)

INSERT INTO Inventory(ProductId, StoreId,Quantity)
VALUES ((select Id from Product where Product.ProductName like N'%سونی%'),(select Id from Store where StoreName like N'%مرکزی%'),30)

INSERT INTO Inventory(ProductId, StoreId,Quantity)
VALUES ((select Id from Product where Product.ProductName like N'%ایسوس%'),(select Id from Store where StoreName like N'%مرکزی%'),70)

INSERT INTO Inventory(ProductId, StoreId,Quantity)
VALUES ((select Id from Product where Product.ProductName like N'%کوله پشتی%'),(select Id from Store where StoreName like N'%مرکزی%'),400)

INSERT INTO Inventory(ProductId, StoreId,Quantity)
VALUES ((select Id from Product where Product.ProductName like N'%آنر%'),(select Id from Store where StoreName like N'%مرکزی%'),100);


Drop TABLE IF EXISTS Customer;
Go
CREATE TABLE Customer
(
	Id uniqueidentifier NOT NULL,
	CustomerName NVARCHAR(150) NOT NULL,
	Phonenumber NVARCHAR(11) NOT NULL,
	CustomerType int not null,--1=حقیقی, 2=حقوقی
	Primary Key(Id),
	
);
GO

INSERT INTO Customer(Id, CustomerName,Phonenumber,CustomerType)
VALUES (NEWID(),N'حاجبی','09137625980',1)
INSERT INTO Customer(Id, CustomerName,Phonenumber,CustomerType)
VALUES (NEWID(),N'محمدی','09123318749',1)
INSERT INTO Customer(Id, CustomerName,Phonenumber,CustomerType)
VALUES (NEWID(),N'محمودی','09121231122',1)
INSERT INTO Customer(Id, CustomerName,Phonenumber,CustomerType)
VALUES (NEWID(),N'حسینی','09121232233',1);


Drop TABLE IF EXISTS State;
Go
CREATE TABLE State
(
	Id uniqueidentifier NOT NULL,
	Name NVARCHAR(11) NOT NULL,
	Primary Key(Id)
);
GO
INSERT INTO State(Id,Name)
VALUES (NEWID(),N'کرمان')
INSERT INTO State(Id,Name)
VALUES (NEWID(),N'فارس')
INSERT INTO State(Id,Name)
VALUES (NEWID(),N'اصفهان')
INSERT INTO State(Id,Name)
VALUES (NEWID(),N'تهران');

Drop TABLE IF EXISTS City;
Go
CREATE TABLE City
(
	Id uniqueidentifier NOT NULL,
	StateId uniqueidentifier,
	Name NVARCHAR(11) NOT NULL,
	Primary Key(Id),
	Foreign Key(StateId) References State
		on delete no action
		on update no action
);
GO

INSERT INTO City(Id, StateId,Name)
VALUES (NEWID(),(select State.Id from state where State.Name like N'%کرمان%'),N'جیرفت')
INSERT INTO City(Id, StateId,Name)
VALUES (NEWID(),(select State.Id from state where State.Name like N'%کرمان%'),N'سیرجان')
INSERT INTO City(Id, StateId,Name)
VALUES (NEWID(),(select State.Id from state where State.Name like N'%فارس%'),N'زرقان')
INSERT INTO City(Id, StateId,Name)
VALUES (NEWID(),(select State.Id from state where State.Name like N'%فارس%'),N'شیراز')
INSERT INTO City(Id, StateId,Name)
VALUES (NEWID(),(select State.Id from state where State.Name like N'%اصفهان%'),N'شاهین شهر')
INSERT INTO City(Id, StateId,Name)
VALUES (NEWID(),(select State.Id from state where State.Name like N'%اصفهان%'),N'اصفهان')
INSERT INTO City(Id, StateId,Name)
VALUES (NEWID(),(select State.Id from state where State.Name like N'%فارس%'),N'مرودشت');

Drop TABLE IF EXISTS Address;
Go
CREATE TABLE Address
(
	Id uniqueidentifier NOT NULL,
	CityId uniqueidentifier NOT NULL,
	StateId uniqueidentifier NOT NULL,
	Discription NVARCHAR(150) NOT NULL,
	PostaCode NVARCHAR(10) NOT NULL,
	Primary Key(Id),
	Foreign Key(CityId) References City
		on delete no action
		on update no action,
	Foreign Key(StateId) References State
		on delete no action
		on update no action,
	

);
GO

INSERT INTO Address(Id, CityId,StateId,Discription,PostaCode)
VALUES (NEWID(),(select City.Id from City where City.Name like N'%زرقان%'),(select State.Id from State where State.Name like N'%فارس%'),N'رز8 واحد 9',N'7341193655');

INSERT INTO Address(Id, CityId,StateId,Discription,PostaCode)
VALUES (NEWID(),(select City.Id from City where City.Name like N'%جیرفت%'),(select State.Id from State where State.Name like N'%کرمان%'),N'خیابان ولایت 1 کوچه ولایت 28',N'7861645379');

INSERT INTO Address(Id, CityId,StateId,Discription,PostaCode)
VALUES (NEWID(),(select City.Id from City where City.Name like N'%شاهین شهر%'),(select State.Id from State where State.Name like N'%اصفهان%'),N'خیابان اصلی کوچه 8',N'7589456123');

Drop Table If Exists Customer_Address;
GO
CREATE TABLE Customer_Address
(
	CustomerId uniqueidentifier NOT NULL,
	AddressId uniqueidentifier NOT NULL,
	Primary Key(CustomerId,AddressId),
	Foreign Key(AddressId) References Address
		on delete no action
		on update no action,
	Foreign Key(CustomerId) References Customer
		on delete no action
		on update no action,
);
GO

Insert Into Customer_Address(CustomerId,AddressId)
values((select Id from Customer where Customer.CustomerName like N'%حاجبی%'),(select Address.Id from Address inner join State on Address.StateId=State.Id join City on City.Id=Address.CityId and City.Name like N'%زرقان%'));
Insert Into Customer_Address(CustomerId,AddressId)
values((select Id from Customer where Customer.CustomerName like N'%حسینی%'),(select Address.Id from Address inner join State on Address.StateId=State.Id join City on City.Id=Address.CityId and City.Name like N'%جیرفت%' ));
Insert Into Customer_Address(CustomerId,AddressId)
values((select Id from Customer where Customer.CustomerName like N'%محمدی%'),(select Address.Id from Address inner join State on Address.StateId=State.Id join City on City.Id=Address.CityId and City.Name like N'%شاهین شهر%' ));

--تخفیف
Drop TABLE IF EXISTS Discount;
Go
CREATE TABLE Discount
(
	Id uniqueidentifier NOT NULL,
	PerType int,--PerCustomer=1,PerCategory=2,PerProduct=4,Perseason=8
	Type int,--ValueDiscount=1,PercentDiscount=2\
	Quantity decimal(12,4),
	Primary Key(Id),
);
GO
insert into Discount(id,PerType,Type,Quantity)
values(NEWID(),1,1,25000);


Drop TABLE IF EXISTS AssignDiscount;
Go
CREATE TABLE AssignDiscount
(
	Id uniqueidentifier NOT NULL,
	discountId uniqueidentifier,
	startDate dateTime,
	endDate dateTime,
	Primary Key(Id),
	foreign key (DiscountId) references Discount
		on delete No Action
		on update No Action
);
GO
insert into AssignDiscount(id,discountId,startDate,endDate)
values(NEWID(),(select TOP(1)id from Discount where Quantity=25000),(SELECT DATEADD(month, -2, GETDATE())),(SELECT DATEADD(month, 1, GETDATE())));

Drop TABLE IF EXISTS Order_;
Go
CREATE TABLE Order_
(
	Id uniqueidentifier NOT NULL,
	CreateionDate DATETIME ,
	LastModficationDate DATETIME ,
	--DiscountId uniqueidentifier ,
	--TotalPrice decimal(18,4),
	--TotalDiscount decimal(18,4),
	CustomerId uniqueidentifier,
	Status int,--Darf=1,Approved=2,Cancel=3,Send=4
	Primary Key(Id),
	Foreign Key(CustomerId) References Customer
		on delete set null
		on update no action,
	--foreign key (DiscountId) references Discount
	--	on delete No Action
	--	on update No Action
);
GO

INSERT INTO Order_(Id,CreateionDate,LastModficationDate,CustomerId,Status)
VALUES(NEWID(),(SELECT DATEADD(month, -2, GETDATE())),(SELECT DATEADD(month, -1, GETDATE())),(select Id from Customer where Customer.CustomerName like N'%حسینی%'),4);

INSERT INTO Order_(Id,CreateionDate,LastModficationDate,CustomerId,Status)
VALUES(NEWID(),(SELECT DATEADD(month, -1, GETDATE())),(SELECT DATEADD(month, -1, GETDATE())),(select Id from Customer where Customer.CustomerName like N'%حاجبی%'),4);

INSERT INTO Order_(Id,CreateionDate,LastModficationDate,CustomerId,Status)
VALUES(NEWID(),(SELECT DATEADD(month, -3, GETDATE())),(SELECT DATEADD(month, -2, GETDATE())),(select Id from Customer where Customer.CustomerName like N'%محمدی%'),4);

Drop TABLE IF EXISTS OrderLine;
Go
CREATE TABLE OrderLine
(
	Id uniqueidentifier NOT NULL,
	ProductId uniqueidentifier NOT NULL,
	OrderId uniqueidentifier NOT NULL,
	NetPrice decimal(18,4),
	Quantity decimal(18,6),
	--DiscountId uniqueidentifier,
	Primary key (Id),
	foreign key (ProductId) references Product
		on delete No Action
		on update No Action,
	foreign key (OrderId) references Order_
		on delete No Action
		on update No Action,
	--foreign key (DiscountId) references Discount
	--	on delete No Action
	--	on update No Action

);
GO

INSERT INTO OrderLine(Id,ProductId,OrderId,NetPrice,Quantity)
VALUES(NEWID(),(SELECT Id FROM Product WHERE Product.ProductName Like N'%سامسونگ%'),(SELECT Order_.Id FROM Customer join Order_ on Customer.Id=Order_.CustomerId and Customer.CustomerName like N'%حاجبی%' ),(SELECT Price.MainPrice FROM Price JOIN Product ON Price.ProductId=Product.Id and Product.ProductName Like N'%سامسونگ%'),1)
INSERT INTO OrderLine(Id,ProductId,OrderId,NetPrice,Quantity)
VALUES(NEWID(),(SELECT Id FROM Product WHERE Product.ProductName Like N'%کوله پشتی%'),(SELECT Order_.Id FROM Customer join Order_ on Customer.Id=Order_.CustomerId and Customer.CustomerName like N'%حاجبی%'),(SELECT Price.MainPrice FROM Price JOIN Product ON Price.ProductId=Product.Id and Product.ProductName Like N'%کوله پشتی%'),4)
INSERT INTO OrderLine(Id,ProductId,OrderId,NetPrice,Quantity)
VALUES(NEWID(),(SELECT Id FROM Product WHERE Product.ProductName Like N'%اچ پی%'),(SELECT Order_.Id FROM Customer join Order_ on Customer.Id=Order_.CustomerId and Customer.CustomerName like N'%محمدی%'),(SELECT Price.MainPrice FROM Price JOIN Product ON Price.ProductId=Product.Id and Product.ProductName Like N'%اچ پی%'),1)
INSERT INTO OrderLine(Id,ProductId,OrderId,NetPrice,Quantity)
VALUES(NEWID(),(SELECT Id FROM Product WHERE Product.ProductName Like N'%کیف دستی%'),(SELECT Order_.Id FROM Customer join Order_ on Customer.Id=Order_.CustomerId and Customer.CustomerName like N'%محمدی%'),(SELECT Price.MainPrice FROM Price JOIN Product ON Price.ProductId=Product.Id and Product.ProductName Like N'%کیف دستی%'),5)
INSERT INTO OrderLine(Id,ProductId,OrderId,NetPrice,Quantity)
VALUES(NEWID(),(SELECT Id FROM Product WHERE Product.ProductName Like N'%سونی%'),(SELECT Order_.Id FROM Customer join Order_ on Customer.Id=Order_.CustomerId and Customer.CustomerName like N'%حسینی%'),(SELECT Price.MainPrice FROM Price JOIN Product ON Price.ProductId=Product.Id and Product.ProductName Like N'%سونی%'),1)
INSERT INTO OrderLine(Id,ProductId,OrderId,NetPrice,Quantity)
VALUES(NEWID(),(SELECT Id FROM Product WHERE Product.ProductName Like N'%کوله پشتی%'),(SELECT Order_.Id FROM Customer join Order_ on Customer.Id=Order_.CustomerId and Customer.CustomerName like N'%حسینی%'),(SELECT Price.MainPrice FROM Price JOIN Product ON Price.ProductId=Product.Id and Product.ProductName Like N'%کوله پشتی%'),3)


-----------------------query--------------------
--select city.Name , State.Name
--from Address join State on Address.StateId=State.Id join City on City.Id=Address.CityId 
Drop View If Exists Addr;
Go
CREATE VIEW Addr(Id, Statename,Cityname )As select Address.Id, State.Name, City.Name  from Address join State on Address.StateId=State.Id join City on City.Id=Address.CityId;
Go
--select * from Addr

Drop View If Exists Customer_Addr;
Go
CREATE VIEW Customer_Addr(CustomerName,Statename,Cityname)As select Customer.CustomerName,Addr.Statename ,Addr.Cityname from Customer_Address join Customer on Customer_Address.CustomerId = Customer.Id join Addr on Customer_Address.AddressId=Addr.Id;
Go
select * from Customer_Addr

Drop View If Exists Price_Of_Product;
Go
CREATE VIEW Price_Of_Product(Id,Name,Price)As SELECT Product.Id, Product.ProductName, Price.MainPrice FROM Price JOIN Product ON Price.ProductId=Product.Id and Product.Id=Price.ProductId
Go
select * from Price_Of_Product

Drop View If Exists Orders;
Go
CREATE VIEW Orders(OrderId,CustomerId,LastModficationDate,NetPrice,ProductId,Quantity)As select Order_.Id,Order_.CustomerId,Order_.LastModficationDate,OrderLine.NetPrice,OrderLine.ProductId,OrderLine.Quantity From OrderLine join Order_ on OrderLine.OrderId=Order_.Id
GO
select * from Orders

Drop View If Exists Orders_Customer;
Go
CREATE VIEW Orders_Customer(CustomerId,Product_Name,Price_Of_Product,LastModficationDate,Quantity)AS select Orders.CustomerId,Price_Of_Product.Name,Price_Of_Product.Price,Orders.LastModficationDate,Orders.Quantity from Orders join Price_Of_Product on Price_Of_Product.Id=Orders.ProductId 
go


select * from Orders_Customer
select CustomerId ,SUM(Price_Of_Product) from Orders_Customer group by CustomerId 

select Product.ProductName,OrderLine.Quantity,OrderLine.NetPrice
from Order_ join OrderLine on Order_.Id=OrderLine.OrderId join Product on Product.Id=OrderLine.ProductId 

Select MONTH(Order_.LastModficationDate),Product.ProductName,Sum(OrderLine.Quantity)
From Order_ join OrderLine on Order_.Id=OrderLine.OrderId join Product on OrderLine.ProductId=Product.Id
Group By Rollup (Order_.LastModficationDate , Product.ProductName)